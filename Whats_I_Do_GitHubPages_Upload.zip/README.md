# What's I Do — GitHub Pages

## Upload ZIP sekali
1. Buat repository GitHub baru (contoh `whats-i-do`).
2. Pada halaman repo, pilih **Add file → Upload files**.
3. Upload isi ZIP (extract ZIP dulu di HP/komputer; upload file-file di dalam folder, bukan ZIP mentah).
4. Commit.

## Tambahkan workflow
Buat file baru di repository dengan path:
`.github/workflows/deploy.yml`
Isi file pakai workflow yang disediakan terpisah.

## Aktifkan Pages
Setelah workflow ditambahkan, buka **Actions** dan pastikan deployment selesai hijau.
Buka **Settings → Pages**; Source pilih **GitHub Actions** bila belum otomatis.
Alamat Pages akan muncul di sana.

## Install di Android
Buka URL Pages lewat Chrome → menu ⋮ → **Add to Home screen** atau **Install app** (jika tersedia).
Aplikasi menggunakan localStorage di browser/perangkat; data tidak otomatis tersinkron ke GitHub atau perangkat lain.

Catatan: GitHub Pages menerbitkan web app, bukan APK Android native. Untuk membuat APK, perlu langkah pembungkus WebView/TWA terpisah.
